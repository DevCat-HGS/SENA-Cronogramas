const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

// Database connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Auth routes
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const [users] = await pool.query(
      'SELECT * FROM Instructor WHERE Correo = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = users[0];
    const validPassword = await bcrypt.compare(password, user.Password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.ID_Instructor, role: user.Rol },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.ID_Instructor,
        nombre: user.Nombre,
        apellido: user.Apellido,
        correo: user.Correo,
        rol: user.Rol
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}); <boltAction type="file" filePath="server/index.js">// Instructor routes
app.get('/api/instructors', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Instructor');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/instructors/:id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM Instructor WHERE ID_Instructor = ?',
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Instructor not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Instructor activities
app.get('/api/instructors/:id/activities', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT af.*
      FROM Actividad_Formacion af
      JOIN Instructor_Actividad ia ON af.ID_Actividad = ia.ID_Actividad
      WHERE ia.ID_Instructor = ?
    `, [req.params.id]);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Instructor events
app.get('/api/instructors/:id/events', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT e.*
      FROM Evento e
      JOIN Instructor_Evento ie ON e.ID_Evento = ie.ID_Evento
      WHERE ie.ID_Instructor = ?
    `, [req.params.id]);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update instructor profile
app.put('/api/instructors/:id', authenticateToken, async (req, res) => {
  const { Nombre, Apellido, Correo, currentPassword, newPassword } = req.body;
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    if (newPassword) {
      const [user] = await connection.query(
        'SELECT Password FROM Instructor WHERE ID_Instructor = ?',
        [req.params.id]
      );

      const validPassword = await bcrypt.compare(currentPassword, user[0].Password);
      if (!validPassword) {
        throw new Error('Current password is incorrect');
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await connection.query(
        'UPDATE Instructor SET Nombre = ?, Apellido = ?, Correo = ?, Password = ? WHERE ID_Instructor = ?',
        [Nombre, Apellido, Correo, hashedPassword, req.params.id]
      );
    } else {
      await connection.query(
        'UPDATE Instructor SET Nombre = ?, Apellido = ?, Correo = ? WHERE ID_Instructor = ?',
        [Nombre, Apellido, Correo, req.params.id]
      );
    }

    await connection.commit();
    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    await connection.rollback();
    res.status(500).json({ error: error.message });
  } finally {
    connection.release();
  }
});

// Coordinator specific routes
app.get('/api/coordinator/stats', authenticateToken, async (req, res) => {
  if (req.user.role !== 'coordinator') {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    const [[instructorCount]] = await pool.query('SELECT COUNT(*) as count FROM Instructor');
    const [[activityCount]] = await pool.query('SELECT COUNT(*) as count FROM Actividad_Formacion');
    const [[eventCount]] = await pool.query('SELECT COUNT(*) as count FROM Evento');
    
    const [pendingEvents] = await pool.query(`
      SELECT COUNT(*) as count 
      FROM Evento 
      WHERE Fecha_Entrega >= CURDATE()
    `);

    const [totalHours] = await pool.query(`
      SELECT SUM(Total_Horas) as total 
      FROM Actividad_Formacion 
      WHERE Fecha_Desde >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    `);

    res.json({
      instructors: instructorCount.count,
      activities: activityCount.count,
      events: eventCount.count,
      pendingEvents: pendingEvents[0].count,
      totalHours: totalHours[0].total || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});