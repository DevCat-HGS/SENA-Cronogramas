import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import InstructorDashboard from './pages/instructor/InstructorDashboard';
import InstructorProfile from './pages/instructor/InstructorProfile';
import InstructorActivities from './pages/instructor/InstructorActivities';
import InstructorEvents from './pages/instructor/InstructorEvents';
import CoordinatorDashboard from './pages/coordinator/CoordinatorDashboard';
import AdminDashboard from './pages/admin/AdminDashboard';
import Navbar from './components/Navbar';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Protected Routes */}
          <Route
            path="/instructor/*"
            element={
              <PrivateRoute roles={['instructor']}>
                <div className="min-h-screen bg-gray-50">
                  <Navbar />
                  <main className="container mx-auto px-4 py-8">
                    <Routes>
                      <Route path="/" element={<InstructorDashboard />} />
                      <Route path="/profile" element={<InstructorProfile />} />
                      <Route path="/activities" element={<InstructorActivities />} />
                      <Route path="/events" element={<InstructorEvents />} />
                    </Routes>
                  </main>
                </div>
              </PrivateRoute>
            }
          />

          <Route
            path="/coordinator/*"
            element={
              <PrivateRoute roles={['coordinator']}>
                <div className="min-h-screen bg-gray-50">
                  <Navbar />
                  <main className="container mx-auto px-4 py-8">
                    <Routes>
                      <Route path="/" element={<CoordinatorDashboard />} />
                      {/* Add other coordinator routes */}
                    </Routes>
                  </main>
                </div>
              </PrivateRoute>
            }
          />

          <Route
            path="/admin/*"
            element={
              <PrivateRoute roles={['admin']}>
                <div className="min-h-screen bg-gray-50">
                  <Navbar />
                  <main className="container mx-auto px-4 py-8">
                    <Routes>
                      <Route path="/" element={<AdminDashboard />} />
                      {/* Add other admin routes */}
                    </Routes>
                  </main>
                </div>
              </PrivateRoute>
            }
          />

          {/* Redirect based on role */}
          <Route
            path="*"
            element={
              <PrivateRoute>
                {({ user }) => {
                  if (user.rol === 'admin') return <Navigate to="/admin" replace />;
                  if (user.rol === 'coordinator') return <Navigate to="/coordinator" replace />;
                  return <Navigate to="/instructor" replace />;
                }}
              </PrivateRoute>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;