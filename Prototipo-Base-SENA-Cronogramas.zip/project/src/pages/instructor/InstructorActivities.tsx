import React, { useState, useEffect } from 'react';
import { Plus, Search, Download } from 'lucide-react';
import ActivityForm from '../../components/activities/ActivityForm';
import ActivityList from '../../components/activities/ActivityList';
import { getInstructorActivities, createActivity } from '../../services/activityService';
import { useAuth } from '../../contexts/AuthContext';
import { useReactToPrint } from 'react-to-print';

const InstructorActivities = () => {
  const { user } = useAuth();
  const [activities, setActivities] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const componentRef = React.useRef();

  useEffect(() => {
    loadActivities();
  }, [user.id]);

  const loadActivities = async () => {
    const data = await getInstructorActivities(user.id);
    setActivities(data);
  };

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'Cronograma_Actividades'
  });

  const filteredActivities = activities.filter(
    (activity) =>
      activity.Numero_Ficha.includes(searchTerm) ||
      activity.Fase_Proyecto.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Mis Actividades</h1>
        <div className="flex space-x-4">
          <button
            onClick={handlePrint}
            className="bg-green-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <Download className="w-4 h-4 mr-2" />
            Descargar Cronograma
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nueva Actividad
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por número de ficha o fase..."
            className="pl-10 w-full p-2 border rounded-md"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div ref={componentRef}>
          <ActivityList
            activities={filteredActivities}
            showActions={false}
          />
        </div>
      </div>

      {showForm && (
        <ActivityForm
          onClose={() => setShowForm(false)}
          onSave={async (activityData) => {
            await createActivity({ ...activityData, instructorIds: [user.id] });
            loadActivities();
            setShowForm(false);
          }}
          singleInstructor
          instructorId={user.id}
        />
      )}
    </div>
  );
};

export default InstructorActivities;