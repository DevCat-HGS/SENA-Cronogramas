import React, { useState, useEffect } from 'react';
import { Plus, Search, Download } from 'lucide-react';
import EventForm from '../../components/events/EventForm';
import EventList from '../../components/events/EventList';
import { getInstructorEvents, createEvent } from '../../services/eventService';
import { useAuth } from '../../contexts/AuthContext';
import { useReactToPrint } from 'react-to-print';

const InstructorEvents = () => {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const componentRef = React.useRef();

  useEffect(() => {
    loadEvents();
  }, [user.id]);

  const loadEvents = async () => {
    const data = await getInstructorEvents(user.id);
    setEvents(data);
  };

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'Cronograma_Eventos'
  });

  const filteredEvents = events.filter(
    (event) =>
      event.Nombre_Evento.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Mis Eventos</h1>
        <div className="flex space-x-4">
          <button
            onClick={handlePrint}
            className="bg-green-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <Download className="w-4 h-4 mr-2" />
            Descargar Cronograma
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Evento
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar eventos..."
            className="pl-10 w-full p-2 border rounded-md"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div ref={componentRef}>
          <EventList
            events={filteredEvents}
            showActions={false}
          />
        </div>
      </div>

      {showForm && (
        <EventForm
          onClose={() => setShowForm(false)}
          onSave={async (eventData) => {
            await createEvent({ ...eventData, instructorIds: [user.id] });
            loadEvents();
            setShowForm(false);
          }}
          singleInstructor
          instructorId={user.id}
        />
      )}
    </div>
  );
};

export default InstructorEvents;