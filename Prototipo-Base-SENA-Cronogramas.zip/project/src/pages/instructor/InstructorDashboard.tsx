import React, { useState, useEffect } from 'react';
import { Calendar, Clock, FileText, Settings, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import Calendar from 'react-calendar';
import { getInstructorActivities } from '../../services/activityService';
import { getInstructorEvents } from '../../services/eventService';
import { useAuth } from '../../contexts/AuthContext';

const InstructorDashboard = () => {
  const { user } = useAuth();
  const [activities, setActivities] = useState([]);
  const [events, setEvents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    loadInstructorData();
  }, [user.id]);

  const loadInstructorData = async () => {
    const activitiesData = await getInstructorActivities(user.id);
    const eventsData = await getInstructorEvents(user.id);
    setActivities(activitiesData);
    setEvents(eventsData);
  };

  const menuItems = [
    { icon: User, label: 'Mi Perfil', path: '/instructor/profile' },
    { icon: Clock, label: 'Mis Actividades', path: '/instructor/activities' },
    { icon: FileText, label: 'Mis Eventos', path: '/instructor/events' },
    { icon: Settings, label: 'Configuración', path: '/instructor/settings' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">
          Bienvenido, {user.nombre} {user.apellido}
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {menuItems.map(({ icon: Icon, label, path }) => (
          <Link
            key={path}
            to={path}
            className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <Icon className="w-8 h-8 text-indigo-600" />
              <span className="text-lg font-medium text-gray-900">{label}</span>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">Calendario</h2>
          <Calendar
            onChange={setSelectedDate}
            value={selectedDate}
            className="w-full"
            tileContent={({ date }) => {
              const hasActivity = activities.some(
                act => new Date(act.Fecha_Desde).toDateString() === date.toDateString()
              );
              const hasEvent = events.some(
                evt => new Date(evt.Fecha_Entrega).toDateString() === date.toDateString()
              );
              return hasActivity || hasEvent ? (
                <div className="h-2 w-2 bg-indigo-600 rounded-full mx-auto"></div>
              ) : null;
            }}
          />
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">Próximas Actividades</h2>
          <div className="space-y-4">
            {activities
              .filter(act => new Date(act.Fecha_Desde) >= new Date())
              .slice(0, 5)
              .map(activity => (
                <div
                  key={activity.ID_Actividad}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-md"
                >
                  <div>
                    <p className="font-medium">{activity.Fase_Proyecto}</p>
                    <p className="text-sm text-gray-600">
                      Ficha: {activity.Numero_Ficha}
                    </p>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(activity.Fecha_Desde).toLocaleDateString()}
                  </span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstructorDashboard;