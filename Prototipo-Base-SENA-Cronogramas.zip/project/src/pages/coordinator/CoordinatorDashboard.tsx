import React, { useState, useEffect } from 'react';
import { Users, Calendar, FileText, Settings, BarChart2, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getInstructors } from '../../services/instructorService';
import { getActivities } from '../../services/activityService';
import { getEvents } from '../../services/eventService';

const CoordinatorDashboard = () => {
  const [stats, setStats] = useState({
    instructors: 0,
    activities: 0,
    events: 0,
    alerts: 0
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const [instructors, activities, events] = await Promise.all([
      getInstructors(),
      getActivities(),
      getEvents()
    ]);

    const alerts = events.filter(event => {
      const daysUntilDeadline = Math.ceil(
        (new Date(event.Fecha_Entrega) - new Date()) / (1000 * 60 * 60 * 24)
      );
      return daysUntilDeadline <= 3 && daysUntilDeadline >= 0;
    }).length;

    setStats({
      instructors: instructors.length,
      activities: activities.length,
      events: events.length,
      alerts
    });
  };

  const menuItems = [
    { icon: Users, label: 'Instructores', path: '/coordinator/instructors', count: stats.instructors },
    { icon: Calendar, label: 'Actividades', path: '/coordinator/activities', count: stats.activities },
    { icon: FileText, label: 'Eventos', path: '/coordinator/events', count: stats.events },
    { icon: BarChart2, label: 'Reportes', path: '/coordinator/reports' },
    { icon: AlertTriangle, label: 'Alertas', path: '/coordinator/alerts', count: stats.alerts },
    { icon: Settings, label: 'Configuración', path: '/coordinator/settings' }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Panel de Coordinación</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {menuItems.map(({ icon: Icon, label, path, count }) => (
          <Link
            key={path}
            to={path}
            className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Icon className="w-8 h-8 text-indigo-600" />
                <span className="text-lg font-medium text-gray-900">{label}</span>
              </div>
              {typeof count === 'number' && (
                <span className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full font-medium">
                  {count}
                </span>
              )}
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">Eventos Próximos</h2>
          <div className="space-y-4">
            {/* Lista de eventos próximos */}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">Actividades Recientes</h2>
          <div className="space-y-4">
            {/* Lista de actividades recientes */}
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4">Estadísticas Generales</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-medium text-gray-500">Total Horas Formación</h3>
            <p className="text-2xl font-bold text-indigo-600">0</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-medium text-gray-500">Eventos Completados</h3>
            <p className="text-2xl font-bold text-green-600">0</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-medium text-gray-500">Eventos Pendientes</h3>
            <p className="text-2xl font-bold text-yellow-600">0</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoordinatorDashboard;