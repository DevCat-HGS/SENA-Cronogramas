import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, Calendar, BarChart2 } from 'lucide-react';

const Landing = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-indigo-600">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/8/83/Sena_Colombia_logo.svg" 
              alt="SENA Logo" 
              className="h-24 mx-auto mb-8"
            />
            <h1 className="text-4xl font-bold text-white mb-4">
              Sistema de Gestión de Instructores SENA
            </h1>
            <p className="text-xl text-indigo-100 mb-8">
              Optimiza la gestión de actividades, eventos y reportes de instructores
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                to="/login"
                className="bg-white text-indigo-600 px-6 py-3 rounded-md font-medium hover:bg-indigo-50"
              >
                Iniciar Sesión
              </Link>
              <Link
                to="/register"
                className="border-2 border-white text-white px-6 py-3 rounded-md font-medium hover:bg-indigo-700"
              >
                Registrarse
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <BookOpen className="w-12 h-12 text-indigo-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Gestión de Actividades</h3>
            <p className="text-gray-600">
              Organiza y controla las actividades de formación de manera eficiente
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Users className="w-12 h-12 text-indigo-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Control de Instructores</h3>
            <p className="text-gray-600">
              Administra la información y asignaciones de los instructores
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Calendar className="w-12 h-12 text-indigo-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Eventos y Cronogramas</h3>
            <p className="text-gray-600">
              Planifica y realiza seguimiento a eventos importantes
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <BarChart2 className="w-12 h-12 text-indigo-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Reportes Detallados</h3>
            <p className="text-gray-600">
              Genera informes y estadísticas de las actividades realizadas
            </p>
          </div>
        </div>
      </div>

      {/* About Section */}
      <div className="bg-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Sobre la Aplicación
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Esta plataforma ha sido diseñada específicamente para el SENA con el objetivo
              de facilitar la gestión y seguimiento de las actividades formativas,
              permitiendo una mejor organización y control de los procesos educativos.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Para Instructores
                </h4>
                <p className="text-gray-600">
                  Gestiona tus actividades, horarios y eventos de manera eficiente
                </p>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Para Coordinadores
                </h4>
                <p className="text-gray-600">
                  Supervisa y coordina las actividades de todos los instructores
                </p>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Para Administradores
                </h4>
                <p className="text-gray-600">
                  Control total del sistema y gestión de usuarios
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p className="mb-2">© 2024 SENA - Servicio Nacional de Aprendizaje</p>
            <p className="text-gray-400">
              Sistema de Gestión de Instructores
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;