import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

export const getInstructors = async () => {
  const response = await axios.get(`${API_URL}/instructors`);
  return response.data;
};

export const getInstructorById = async (id) => {
  const response = await axios.get(`${API_URL}/instructors/${id}`);
  return response.data;
};

export const getInstructorActivities = async (id) => {
  const response = await axios.get(`${API_URL}/instructors/${id}/activities`);
  return response.data;
};

export const getInstructorEvents = async (id) => {
  const response = await axios.get(`${API_URL}/instructors/${id}/events`);
  return response.data;
};

export const updateInstructor = async (id, data) => {
  const response = await axios.put(`${API_URL}/instructors/${id}`, data);
  return response.data;
};